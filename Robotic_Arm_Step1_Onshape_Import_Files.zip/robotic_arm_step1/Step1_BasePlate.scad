// Robotic Arm - Step 1 Base Plate
// Units: millimeters. Import this file into OpenSCAD to inspect/edit.
// Nominal design: 140 x 140 x 8 plate; 4 x Ø6 holes on 110 x 110 pitch;
// central 608ZZ bearing pocket Ø22.2 x 7 deep, with Ø8 through-hole.

$fn = 128;
plate_x = 140;
plate_y = 140;
plate_t = 8;
corner_hole_d = 6;
corner_pitch = 110;
bearing_pocket_d = 22.2; // slight clearance for a 22 mm OD bearing; tune to fabrication method
bearing_pocket_depth = 7;
center_through_d = 8;

 difference() {
    translate([-plate_x/2, -plate_y/2, 0])
        cube([plate_x, plate_y, plate_t]);

    // Four mounting holes, 110 mm center-to-center in X and Y
    for (x = [-corner_pitch/2, corner_pitch/2])
        for (y = [-corner_pitch/2, corner_pitch/2])
            translate([x, y, -0.1])
                cylinder(h = plate_t + 0.2, d = corner_hole_d);

    // Bearing counterbore from top surface; leaves 1 mm floor before through-hole
    translate([0, 0, plate_t - bearing_pocket_depth])
        cylinder(h = bearing_pocket_depth + 0.1, d = bearing_pocket_d);

    // Central through-hole, aligned to the bearing bore
    translate([0, 0, -0.1])
        cylinder(h = plate_t + 0.2, d = center_through_d);
}
